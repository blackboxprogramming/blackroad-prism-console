import fetch from 'node-fetch';
const API = 'https://api.linear.app/graphql';

type CreateIssueInput = { title: string; description?: string; labels?: string[] };

export async function createLinearIssue(input: CreateIssueInput) {
  const token = process.env.LINEAR_API_KEY;
  if (!token) throw new Error('LINEAR_API_KEY missing');
  const query = `mutation($title:String!, $description:String){
    issueCreate(input:{ title:$title, description:$description }){
      success issue { id identifier url }
    }
  }`;
  const res = await fetch(API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
    body: JSON.stringify({ query, variables: { title: input.title, description: input.description ?? '' } })
  });
  const data = await res.json();
  return data?.data?.issueCreate?.issue ?? { error: data };
}
