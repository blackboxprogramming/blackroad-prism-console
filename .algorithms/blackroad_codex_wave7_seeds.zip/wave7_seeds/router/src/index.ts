import express from 'express';
import bodyParser from 'body-parser';
import { createLinearIssue } from './providers/linear.js';

const app = express();
app.use(bodyParser.json({ type: '*/*' }));

app.get('/healthz', (_req, res) => res.json({ ok: true }));

app.post('/webhooks/slack/command', async (req, res) => {
  const { text, user_id, channel_id } = req.body || {};
  const title = `[CODEx] ${text?.slice(0, 80) ?? 'task'}`;
  const description = `Source: Slack user ${user_id} in ${channel_id}\n\n${text}`;
  const issue = await createLinearIssue({ title, description, labels: ['automation'] }).catch(err => ({ error: String(err) }));
  res.json({ response_type: 'in_channel', text: issue?.url ?? 'Created task' });
});

app.post('/webhooks/slack/events', async (req, res) => {
  if (req.body?.type === 'url_verification') return res.send(req.body.challenge);
  try {
    const event = req.body.event;
    if (event && typeof event.text === 'string' && event.text.includes('@codex')) {
      const title = `[CODEx] ${event.text.slice(0, 80)}`;
      const description = `Slack event in ${event.channel}:\n\n${event.text}`;
      await createLinearIssue({ title, description, labels: ['automation'] });
    }
    res.sendStatus(200);
  } catch {
    res.sendStatus(500);
  }
});

app.post('/webhooks/github', async (req, res) => {
  try {
    const ev = req.headers['x-github-event'];
    if (ev === 'issue_comment' && req.body?.comment?.body?.includes('@codex')) {
      const body = req.body.comment.body as string;
      const title = `[CODEx] GH: ${body.slice(0, 80)}`;
      const description = `Repo ${req.body.repository.full_name} #${req.body.issue.number}\n\n${body}`;
      await createLinearIssue({ title, description, labels: ['automation'] });
    }
    res.sendStatus(200);
  } catch {
    res.sendStatus(500);
  }
});

app.post('/webhooks/notion', async (_req, res) => res.sendStatus(200));

app.post('/webhooks/datadog', async (req, res) => {
  const alert = req.body;
  const title = `[SLO] ${alert?.title ?? 'Datadog Alert'}`;
  const description = 'Auto-opened from Datadog webhook';
  await createLinearIssue({ title, description, labels: ['incident'] });
  res.sendStatus(200);
});

const port = process.env.PORT || 8080;
app.listen(port, () => console.log(`codex-router listening on ${port}`));
