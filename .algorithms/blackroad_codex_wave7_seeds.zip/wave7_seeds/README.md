# BlackRoad Codex — Wave 7 Seeds
Minimal router & manifests so `@codex` comments become Linear issues and alerts create incidents.

## Quick start
1) Copy `router/.env.example` to `.env` and fill secrets.
2) Build & run:
   docker compose up --build
3) Install Slack app using `slack/manifest.yaml` (Events/Interactivity URLs point to your router).
4) Create GitHub App from `github/app-manifest.json` and subscribe to `issue_comment` and `pull_request`.
5) (Optional) Seed Linear labels:
   LINEAR_API_KEY=... linear/seed_linear.sh
