#!/usr/bin/env bash
set -euo pipefail
: "${LINEAR_API_KEY:?export LINEAR_API_KEY}"
API="https://api.linear.app/graphql"
HDR=(-H "Content-Type: application/json" -H "Authorization: Bearer ${LINEAR_API_KEY}")
# Seed labels (best-effort; adjust color in UI)
for name in $(jq -r '.[]' linear/labels.json); do
  curl -s "${HDR[@]}" -X POST "$API" -d "$(jq -n --arg n "$name" '{query:"mutation($name:String!){ labelCreate(input:{ name:$name, color:"#4B9CE2"}){ label { id name } } }",variables:{name:$n}}')" >/dev/null || true
done
echo "Seed complete (labels). Verify in Linear."
